---@meta

--- Similar to `thread.exdata` but for a 2nd separate user data as a pointer value.
---@param data? any
---@return any? data
local function exdata2(data) end

return exdata2
