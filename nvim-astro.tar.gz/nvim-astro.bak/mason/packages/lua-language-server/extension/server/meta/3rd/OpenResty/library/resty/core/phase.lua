---@meta
local resty_core_phase={}
resty_core_phase.version = require("resty.core.base").version
return resty_core_phase